def get_requires_for_build_sdist(config_settings):
    return ["intree_backend_called"]
